Travel Command Centre V1 — V51 visual-reference pack

These images are layout / hierarchy / density / interaction-depth evidence. Colours are NOT authority unless Cameron explicitly approved the specific colour elsewhere.

REF_21 COUNTRY QUICK LOOK is approved as the rich presentation direction, with these locked corrections:
- Sidebar label remains Home, not Dashboard.
- Remove Current Destination Status and all fake/current weather or temperature content.
- Use Practical Essentials instead (capital, calling code, plug/power, driving side, payments, tipping and similarly useful offline facts).
- Preserve the rich hero, four substantial information cards, photographic treatment, Language Helper preview, and extra prominence for Plants & Gardens.

REF_22 TOILET HELPER is approved as the rich presentation direction, with these locked corrections:
- Remove Quick Tips.
- Replace it with Signs to Look For (local Toilet/WC, Women, Men, Accessible signs where practical).
- Do not claim 100% offline audio availability unless the target iPad actually exposes a suitable installed local voice.
- Preserve the large native phrase, English meaning, pronunciation, slow breakdown, and four large controls: Play, Slow, Repeat ×3, Louder.
- No online speech API or internet dependency.
